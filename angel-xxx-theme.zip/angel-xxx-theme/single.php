<?php get_header(); ?>
</div>
    <div id="content">
	
<?php if (have_posts()) : ?>
	
<?php while (have_posts()) : the_post(); ?>
			<?php $current_post_id = get_the_ID(); $post_cats = wp_get_post_categories( get_the_ID(), NULL ); sort($post_cats,SORT_NUMERIC); ?>
	
		<div class="page-box" id="post-<?php the_ID(); ?>">
			<div class="pagetop"><h2 class="pagetitle"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2></div>
			
			<div class="entry">
					<?php $video_code = thman_getcustomfield('video_code',get_the_ID()); if(!empty($video_code)) : ?><div class="video_code"><center><?php echo $video_code; ?></center></div><?php endif; ?>
					
<?php $paysite_url = thman_getcustomfield('paysite_url',get_the_ID()); if(!empty($paysite_url)): $paysite_title = thman_getcustomfield('paysite_title',get_the_ID()); if(empty($paysite_title)) $paysite_title = $paysite_url; ?>
						<?php endif; ?>

							<?php the_content('Read the rest of this entry &raquo;'); ?>
                            <div class="entry_info">
                    <p><strong>Duration:</strong> <?php $duration = thman_getcustomfield('duration',get_the_ID()); if(empty($duration)) $duration = '0:00'; echo $duration; ?></p>
                    <?php the_tags('<p class="tags"><strong>Tags:</strong> ', ', ', '</p>'); ?>
					<?php if(function_exists('the_views')) {  ?><p><strong>Views:</strong> <?php the_views(); ?></p><?php } ?>
                    
                    <!-- AddThis Button BEGIN -->
                        <div class="addthis_toolbox addthis_default_style"><p><strong style="float:left">Share:&nbsp;</strong>
                            <a class="addthis_button_favorites"></a>
                            <a class="addthis_button_facebook"></a>
                            <a class="addthis_button_google"></a>
                            <a class="addthis_button_myspace"></a>
                            <a class="addthis_button_twitter"></a>
                        </div>
                        <script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4cbc262d23266465"></script>
                    <!-- AddThis Button END -->
                    </div>
				</div>
</div>
<!-- single_box -->
	<div class="single_box">
		<div class="single_box_title">
			<h2>Related Videos</h2>

		</div>
		<!-- single_content -->
		<div class="single_content">
			<?php
			query_posts('showposts=4&orderby=rand&cat='.implode(',',$post_cats));
			if (have_posts()) : ?>
			<div class="videos2">
            
			<?php $i=0; while (have_posts()) : the_post(); if($current_post_id==get_the_ID()) continue; $i++; ?>
				<!-- post -->
				<div class="video2<?php if($i%5==0) : ?> video_last<?php endif; ?>" id="video-<?php the_ID(); ?>">
					<div class="thumb">
					<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php $thumb = thman_getcustomfield('wtp_thumb_url',get_the_ID()); if(!empty($thumb)) : ?>
						<img src="<?php echo $thumb; ?>" alt="<?php the_title_attribute(); ?>" />
					<?php else : ?>
						<img src="<?php bloginfo('template_url'); ?>/images/pic-empty.jpg" alt="<?php the_title_attribute(); ?>" />
					<?php endif; ?></a>
					</div>
                    <h2 class="posttitle"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo thman_get_limited_string($post->post_title,14); ?></a></h2>
					<div class="info">
                        <div class="info_left">
                            <?php if(function_exists('the_ratings')) { ?><?php the_ratings(); ?><?php } ?>
                        </div>
                        <div class="info_right">
                        <div class="duration" align="right"><?php $duration = thman_getcustomfield('duration',get_the_ID()); if(empty($duration)) $duration = '0:00'; echo $duration; ?></div><br />
                        <div class="views" align="right"><?php if(function_exists('the_views')) {  ?><?php the_views(); ?><?php } ?></div>
                        </div>
                    </div>
				</div>
				<?php if($i%5==0) : ?><?php endif; ?>
				<!-- /post -->
			<?php endwhile; ?>
			</div>
			<?php 
			
			else :
		
				?><p class="nopost">Sorry, but you are looking for something that isn't here.</p><?php
		
			endif; wp_reset_query();
		?>			
		</div>
		<!-- /single_content -->
	</div>
	<!-- /single_box -->
   

	<div class="entry"><br /><br />
	
	<?php endwhile; else: ?>
	
		<p>Sorry, no posts matched your criteria.</p>
	
<?php endif; ?>
	
    </div>	
	
    </div>
    
	<div id="rightnav"><?php include (TEMPLATEPATH . '/sidebar2.php'); ?></div>
	
</div>
<?php get_footer(); ?>