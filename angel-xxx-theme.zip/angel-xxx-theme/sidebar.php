		<ul id="sidebarright">
                
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>

 <li id="advertisements"><?php _e('<h2>Advertisements</h2>'); ?>
	<div>
	<center><a href="#"><img src="http://www.adulttemplatesevolution.com/wordpress-themes/wp0164/thumbs/thumb2.jpg" alt="" /></a></center>
	</div>
</li>
 
 <li id="categories"><?php _e('<h2>Categories</h2>'); ?>
	<ul>
	<?php wp_list_cats('optioncount=1'); ?>


	</ul>
 </li>

<li id="tags"><?php _e('<h2>Tags</h2>'); ?>
    <ul>
    <?php wp_tag_cloud('smallest=10&largest=14&number=20&separator=, '); ?>
    </ul>
</li>


<?php endif; ?>

		</ul>