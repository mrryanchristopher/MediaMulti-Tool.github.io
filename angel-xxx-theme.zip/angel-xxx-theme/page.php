<?php get_header(); ?>
</div>
    <div id="content">

    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="page-box" id="post-<?php the_ID(); ?>">
				<div class="pagetop"><h2 class="pagetitle"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2></div>
				
			<div class="entry">
				<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
	
				<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
	
			</div>
		</div>
	  <?php endwhile; endif; ?>
	  
    </div>
	
    <div id="rightnav"><?php include (TEMPLATEPATH . '/sidebar2.php'); ?></div>
	
</div>
<?php get_footer(); ?>



