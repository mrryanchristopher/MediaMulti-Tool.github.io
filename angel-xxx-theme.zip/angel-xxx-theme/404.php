<?php get_header(); ?>

</div>
    <div id="content">

		<div class="entry"><h3 class="center">Error 404 - Not Found</h3></div>

	</div>
    
	<div id="rightnav"><?php include (TEMPLATEPATH . '/sidebar2.php'); ?></div>
	
</div>
<?php get_footer(); ?>
