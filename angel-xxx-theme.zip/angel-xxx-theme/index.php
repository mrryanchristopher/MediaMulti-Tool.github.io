<?php

get_header();

$orderby = 'date';
$orderby = '&orderby=date';
if(isset($_GET['order']) && !empty($_GET['order']))
{
	$order = $_GET['order'];
	switch($order)
	{ 
		case 'rated' :	$orderby = '&r_sortby=highest_rated&r_orderby=desc';
			break;
		case 'viewed' :	$orderby = '&v_sortby=views&v_orderby=desc';
			break;
		case 'discussed' :	$orderby = '&orderby=comment_count';
				function comment_count_orderby( $orderby ) {
					return "comment_count DESC";
				}
				add_filter('posts_orderby', 'comment_count_orderby');
			break;
		default :	 $orderby = '&orderby=date';
			break;
	}
}
$order_url = get_option('home').'/?order=';
?>

	</div>
    <div id="content">


		<div class="main_title">
				<h2><span class="left"><span class="right">Last Porno Movies</span></span></h2>
			</div>
            
			
			<?php
			query_posts($query_string.$orderby);
			if (have_posts()) : ?>			
		
		<?php $i=0; while (have_posts()) : the_post(); $i++; ?>
				
			<div class="videos">
			<div class="post">
			<div class="video<?php if($i%4==0) : ?> video_last<?php endif; ?>" id="video-<?php the_ID(); ?>">
			
			<div class="thumb">
				<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php $thumb = thman_getcustomfield('wtp_thumb_url',get_the_ID()); if(!empty($thumb)) : ?>
					<img src="<?php echo $thumb; ?>" alt="<?php the_title_attribute(); ?>" />
				<?php else : ?>
					<img src="<?php bloginfo('template_url'); ?>/images/pic-empty.jpg" alt="<?php the_title_attribute(); ?>" />
				<?php endif; ?></a>
			</div>
            <h2 class="posttitle"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo thman_get_limited_string($post->post_title,14); ?></a></h2>
			<div class="info">
				<div class="info_left">
					<?php if(function_exists('the_ratings')) { ?><?php the_ratings(); ?><?php } ?>
				</div>
				<div class="info_right">
				<br />
				<div class="views" align="right"><?php if(function_exists('the_views')) {  ?><?php the_views(); ?><?php } ?></div>
				</div>
			</div>

   </div></div><?php if($i%4==0) : ?><?php endif; ?></div>

   
   
   
				
	
		<?php endwhile; ?>
		
		<div style="clear:both"></div>
		<div class="navigation"><div class="navigation-pagenavi">
			<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?> </div> 
		</div>
		
	<?php else : ?>
	<div class="search" align="center" style="height:200px; padding-top:30px;">
		<h4 class="center">Not Found</h4>
		<h4 class="center">Sorry, but you are looking for something that isn't here.</h4>
	</div>
	<?php endif; ?>
    </div>
	
    <div id="rightnav"><?php get_sidebar(); ?></div>
	

</div>
<?php get_footer(); ?>
