<?php
/*
Template Name: Links
*/
?>
  <div id="container" class="clearfix">

	  <?php get_sidebar(); ?>
</div>
<div id="content">

<h2>Links:</h2>
<ul>
<?php get_links_list(); ?>
</ul>

</div>	
<div id="rightnav"><?php get_sidebar(); ?></div>
</div>
<?php get_footer(); ?>
</body>
</html>