</ul>

	</div>
	<!-- /footer -->
	<?php wp_footer(); ?>
</div>