<?
/**
 * @package WordPress
 * @subpackage magazine_obsession
 */

require_once('fn-admin.php');
require_once('thman-settings.php');

add_action('admin_menu', 'thman_add_menu'); 
 
?>