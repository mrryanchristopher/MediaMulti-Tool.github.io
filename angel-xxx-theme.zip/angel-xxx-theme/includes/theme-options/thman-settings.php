<?
/**
 * @package WordPress
 * @subpackage magazine_obsession
 */

/**
 * Show the General Settings for Admin oanel
 *
 * @since 2.7.0
 *
 */
function thman_general_settings()
{
    global $themename, $options, $shortname;

	$options = array (
				array(	"name" => "Main Settings",
						"type" => "heading"),
						
				array(	"name" => "Show Pages for Menu?",
						"desc" => "<br /><br />",
			    		"id" => $shortname."_menu_type",
			    		"std" => "disable",
						"options" => array("enable", "disable"),
			    		"type" => "select"),
																														
		  );
	
	thman_add_admin('thman-settings.php');
}



?>