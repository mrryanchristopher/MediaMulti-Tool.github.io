<?php

get_header();

$orderby = 'date';
$orderby = '&orderby=date';
if(isset($_GET['order']) && !empty($_GET['order']))
{
	$order = $_GET['order'];
	switch($order)
	{ 
		case 'rated' :	$orderby = '&r_sortby=highest_rated&r_orderby=desc';
			break;
		case 'viewed' :	$orderby = '&v_sortby=views&v_orderby=desc';
			break;
		case 'discussed' :	$orderby = '&orderby=comment_count';
				function comment_count_orderby( $orderby ) {
					return "comment_count DESC";
				}
				add_filter('posts_orderby', 'comment_count_orderby');
			break;
		default :	 $orderby = '&orderby=date';
			break;
	}
}
$order_url = get_option('home').'/?order=';
?>

</div>
    <div id="content">

		<div class="main_title"><?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
			  <?php /* If this is a category archive */ if (is_category()) { ?>
				<h1><span class="left"><span class="right">Todays Free Videos for <?php single_cat_title(); ?></span></span></h1>
			  <?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
				<h1><span class="left"><span class="right">Todays Free Videos for <?php single_tag_title(); ?></span></span></h1>
			  <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
				<h1><span class="left"><span class="right">Todays Free Videos for <?php the_time('F jS, Y'); ?></span></span></h1>
			  <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
				<h1><span class="left"><span class="right">Todays Free Videos for <?php the_time('F, Y'); ?></span></span></h1>
			  <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
				<h1><span class="left"><span class="right">Todays Free Videos for <?php the_time('Y'); ?></span></span></h1>
			  <?php /* If this is an author archive */ } elseif (is_author()) { ?>
				<h1><span class="left"><span class="right">Todays Free Videos by Author</span></span></h1>
			  <?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
				<h1><span class="left"><span class="right">Todays Free Videos</span></span></h1>
			  <?php } ?>
			  </div>
			
			<?php
			query_posts($query_string.$orderby);
			if (have_posts()) : ?>
          			
		
		<?php $i=0; while (have_posts()) : the_post(); $i++; ?>
				
			<div class="videos">
			<div class="post">
			<div class="video<?php if($i%4==0) : ?> video_last<?php endif; ?>" id="video-<?php the_ID(); ?>">
			
			<div class="thumb">
				<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php $thumb = thman_getcustomfield('wtp_thumb_url',get_the_ID()); if(!empty($thumb)) : ?>
					<img src="<?php echo $thumb; ?>" alt="<?php the_title_attribute(); ?>" />
				<?php else : ?>
					<img src="<?php bloginfo('template_url'); ?>/images/pic-empty.jpg" alt="<?php the_title_attribute(); ?>" />
				<?php endif; ?></a>
			</div>
            <h2 class="posttitle"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo thman_get_limited_string($post->post_title,14); ?></a></h2>
			<div class="info">
				<div class="info_left">
					<?php if(function_exists('the_ratings')) { ?><?php the_ratings(); ?><?php } ?>
				</div>
				<div class="info_right">
				<div class="duration" align="right"><?php $duration = thman_getcustomfield('duration',get_the_ID()); if(empty($duration)) $duration = '0:00'; echo $duration; ?></div><br />
				<div class="views" align="right"><?php if(function_exists('the_views')) {  ?><?php the_views(); ?><?php } ?></div>
				</div>
			</div>
	
   </div></div><?php if($i%4==0) : ?><?php endif; ?></div>

   
   
   
				
	
		<?php endwhile; ?>
		
		<div style="clear:both"></div>
		<div class="navigation"><div class="navigation-pagenavi">
			<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?> </div> 
		</div>
		
	<?php else : ?>
	<div class="search" align="center" style="height:160px;">
		<h4 class="center">Not Found</h4>
		<p class="center">Sorry, but you are looking for something that isn't here.</p>
	</div>
	<?php endif; ?>
    </div>
	
    <div id="rightnav"><?php include (TEMPLATEPATH . '/sidebar2.php'); ?></div>
	

</div>
<?php get_footer(); ?>
