<div><img src="<?php bloginfo('stylesheet_directory'); ?>/images/container-footer.jpg" height="12" width="1000" border="0" alt="" /></div>
    
    
   <div class="footer-links-top"></div>
   <div class="footer-links-bg"><center><a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/banner.jpg" alt="" /></a></center></div>
   <div class="footer-links-footer"></div>
   



   
	<div id="footwrap">	

	<div  class="footer-bottom">
		<div  class="footer-bottom-text">
		Copyright © 2017 <a href="http://eporner.wpadultthemes.xyz" title="Eporner" target="_blank" rel="dofollow">Eporner</a> Wordpress Theme. All Right Reserved.</div>
	</div>

</div></div>
</div></div> <?php wp_footer(); ?>  
	
</body>
</html>

