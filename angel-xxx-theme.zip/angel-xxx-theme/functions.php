<?php

$themename = "Tube";
$adminmenuname = "Angel XXX Tube";
$shortname = "thman";

$include_dir = 'includes';
$themeoptions_dir = $include_dir.'/theme-options';

// Functions
require_once($include_dir.'/fn-general.php');
require_once($themeoptions_dir.'/setup.php');

if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
        'after_widget' => '</li>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>',
        'name' => 'Sidebar'
    ));
	    register_sidebar(array(
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
        'after_widget' => '</li>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>',
        'name' => 'Sidebar2'
    ));

	
/**
 * Filter arguments of tag cloud widget to enlarge our text and
 * add commas
 */
add_action('wp_enqueue_scripts', 'wpdocs_scripts_method');
 

function wpdocs_scripts_method() {
    wp_enqueue_script(
        'custom_script',
        get_template_directory_uri() . '/includes/jquery-color.js',
        array('jquery')
    );
}
function myfunc_filter_tag_cloud($args) {
	$args['smallest'] = 12;
	$args['largest'] = 16;
	$args['unit'] = 'px';
	$args['separator']= ', ';
	return $args;
}
add_filter ( 'widget_tag_cloud_args', 'myfunc_filter_tag_cloud');

?>